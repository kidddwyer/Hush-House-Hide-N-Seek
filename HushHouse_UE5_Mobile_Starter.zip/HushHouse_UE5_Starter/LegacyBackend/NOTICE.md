Copied from the existing browser version for migration planning. Not integrated into UE C++ yet. Run separately only after adding secure production configuration.
