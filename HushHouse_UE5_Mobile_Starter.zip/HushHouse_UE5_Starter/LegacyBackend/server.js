/* HUSH HOUSE — zero-dependency asynchronous multiplayer starter.
   Host over HTTPS for friends and random players to reach each other. */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.join(__dirname, 'public');
const DATA = process.env.DATA_FILE || path.join(__dirname, 'game-data.json');
const PORT = Number(process.env.PORT || 3030);
const TURN_LIMIT=24*60*60*1000;
const HIDE_MS=90000, SEEK_MS=180000;
const DAY_MS=24*60*60*1000;
const HOUSE_ID='starter';
const POWER_PACKS={eliminate:{cost:500,quantity:2},hotcold:{cost:500,quantity:2},fifty:{cost:500,quantity:1}};
const ROOMS=['Living Room','Kitchen','Garage','Bedroom','Bathroom'];
const LOCATION_BY_SPOT=Object.fromEntries([...[]]);
const SPOT_DATA={"sectional-main": {"room": "Living Room", "x": 4.95, "z": 7.65}, "sectional-chaise": {"room": "Living Room", "x": 2.95, "z": 8.55}, "media-left": {"room": "Living Room", "x": 4.35, "z": 3.15}, "media-center": {"room": "Living Room", "x": 6.1, "z": 3.15}, "builtin-tall": {"room": "Living Room", "x": 1.3, "z": 2.45}, "builtin-base": {"room": "Living Room", "x": 1.95, "z": 4.85}, "accent-chair": {"room": "Living Room", "x": 8.65, "z": 6.85}, "ottoman": {"room": "Living Room", "x": 7.25, "z": 8.05}, "curtains": {"room": "Living Room", "x": 10.1, "z": 6.0}, "slat-storage": {"room": "Living Room", "x": 10.2, "z": 2.8}, "fridge": {"room": "Kitchen", "x": 12.95, "z": 3.15}, "freezer": {"room": "Kitchen", "x": 12.95, "z": 4.55}, "wall-oven": {"room": "Kitchen", "x": 15.55, "z": 3.25}, "dishwasher": {"room": "Kitchen", "x": 17.95, "z": 3.75}, "sink-cabinet": {"room": "Kitchen", "x": 18.8, "z": 4.9}, "corner-cabinet": {"room": "Kitchen", "x": 21.3, "z": 5.35}, "upper-cabinet": {"room": "Kitchen", "x": 20.4, "z": 2.25}, "island-cabinet": {"room": "Kitchen", "x": 18.4, "z": 8.4}, "appliance-garage": {"room": "Kitchen", "x": 22.95, "z": 4.15}, "pantry": {"room": "Kitchen", "x": 22.5, "z": 8.75}, "suv-interior": {"room": "Garage", "x": 29.6, "z": 5.7}, "suv-cargo": {"room": "Garage", "x": 29.6, "z": 8.3}, "garage-cabinet-left": {"room": "Garage", "x": 25.4, "z": 3.0}, "garage-cabinet-right": {"room": "Garage", "x": 34.55, "z": 3.0}, "garage-overhead-front": {"room": "Garage", "x": 27.5, "z": 2.4}, "garage-overhead-rear": {"room": "Garage", "x": 33.8, "z": 9.8}, "garage-workbench": {"room": "Garage", "x": 34.2, "z": 7.3}, "bed": {"room": "Bedroom", "x": 6.7, "z": 17.5}, "bedroom-bed-storage": {"room": "Bedroom", "x": 2.15, "z": 18.0}, "bedroom-nightstand": {"room": "Bedroom", "x": 7.4, "z": 15.25}, "bedroom-wardrobe": {"room": "Bedroom", "x": 9.5, "z": 21.0}, "bedroom-hanging": {"room": "Bedroom", "x": 8.3, "z": 20.3}, "bedroom-drawers": {"room": "Bedroom", "x": 5.8, "z": 21.7}, "bedroom-low-cabinet": {"room": "Bedroom", "x": 3.2, "z": 22.0}, "bedroom-storage-bench": {"room": "Bedroom", "x": 5.2, "z": 13.6}, "bedroom-basket": {"room": "Bedroom", "x": 1.45, "z": 15.2}, "bedroom-shelf-bin": {"room": "Bedroom", "x": 1.6, "z": 21.5}, "bath-tub": {"room": "Bathroom", "x": 15.6, "z": 20.7}, "bath-shower": {"room": "Bathroom", "x": 21.3, "z": 20.6}, "bath-vanity-left": {"room": "Bathroom", "x": 19.1, "z": 14.1}, "bath-vanity-right": {"room": "Bathroom", "x": 21.5, "z": 14.1}, "bath-linen-tall": {"room": "Bathroom", "x": 13.35, "z": 16.1}, "bath-linen-drawer": {"room": "Bathroom", "x": 13.4, "z": 18.0}, "bath-hamper": {"room": "Bathroom", "x": 16.2, "z": 15.1}, "bath-bench": {"room": "Bathroom", "x": 17.7, "z": 22.1}, "bath-mirror-cabinet": {"room": "Bathroom", "x": 20.0, "z": 13.0}};


const utcDay=ms=>new Date(ms).toISOString().slice(0,10);
const VALID_SPOTS = new Set([
  'sectional-main','sectional-chaise','media-left','media-center','builtin-tall','builtin-base','accent-chair','ottoman','curtains','slat-storage','fridge','freezer','wall-oven','dishwasher','sink-cabinet','corner-cabinet','upper-cabinet','island-cabinet','appliance-garage','pantry','suv-interior','suv-cargo','garage-cabinet-left','garage-cabinet-right','garage-overhead-front','garage-overhead-rear','garage-workbench','bed','bedroom-bed-storage','bedroom-nightstand','bedroom-wardrobe','bedroom-hanging','bedroom-drawers','bedroom-low-cabinet','bedroom-storage-bench','bedroom-basket','bedroom-shelf-bin','bath-tub','bath-shower','bath-vanity-left','bath-vanity-right','bath-linen-tall','bath-linen-drawer','bath-hamper','bath-bench','bath-mirror-cabinet'
]);
let db = {users:{},matches:[]};
if(fs.existsSync(DATA)) {
  try { db = JSON.parse(fs.readFileSync(DATA,'utf8')); } catch(e) { console.error('Invalid data file',e); process.exit(1); }
}
const persist = () => {
  fs.mkdirSync(path.dirname(DATA), {recursive:true});
  const temp = `${DATA}.${process.pid}.tmp`;
  fs.writeFileSync(temp,JSON.stringify(db,null,2)); fs.renameSync(temp, DATA);
};
const secret = () => crypto.randomBytes(32).toString('hex');

// RFC 8291 aes128gcm Web Push + VAPID, implemented with Node crypto.
// HTTPS / supported browser / a valid VAPID_SUBJECT are required for real device pushes.
if(!db.vapid){
  const ec=crypto.createECDH('prime256v1');ec.generateKeys();
  db.vapid={publicKey:ec.getPublicKey().toString('base64url'),privateKey:ec.getPrivateKey().toString('base64url')};
  persist();
}
const vapidSubject=process.env.VAPID_SUBJECT||'';
const b64=v=>Buffer.from(v).toString('base64url');
const hmac=(key,data)=>crypto.createHmac('sha256',key).update(data).digest();
const hkdfExpand=(prk,info,length)=>hmac(prk,Buffer.concat([info,Buffer.from([1])])).subarray(0,length);
const vapidPub=Buffer.from(db.vapid.publicKey,'base64url');
const vapidPriv=crypto.createPrivateKey({format:'jwk',key:{kty:'EC',crv:'P-256',
  x:vapidPub.subarray(1,33).toString('base64url'),y:vapidPub.subarray(33).toString('base64url'),d:db.vapid.privateKey}});
async function sendPush(u,title,body){
  if(!vapidSubject || !u.pushSubscriptions?.length)return;
  const removed=[];
  for(const sub of u.pushSubscriptions){
    try{
      const target=new URL(sub.endpoint);
      if(target.protocol!=='https:')continue;
      const receiverPub=Buffer.from(sub.keys.p256dh,'base64url');
      const authSecret=Buffer.from(sub.keys.auth,'base64url');
      const ephemeral=crypto.createECDH('prime256v1');ephemeral.generateKeys();
      const senderPub=ephemeral.getPublicKey();
      const sharedSecret=ephemeral.computeSecret(receiverPub);
      const prkKey=hmac(authSecret,sharedSecret);
      const info=Buffer.concat([Buffer.from('WebPush: info\0'),receiverPub,senderPub]);
      const ikm=hkdfExpand(prkKey,info,32);
      const salt=crypto.randomBytes(16),prk=hmac(salt,ikm);
      const cek=hkdfExpand(prk,Buffer.from('Content-Encoding: aes128gcm\0'),16);
      const nonce=hkdfExpand(prk,Buffer.from('Content-Encoding: nonce\0'),12);
      const cipher=crypto.createCipheriv('aes-128-gcm',cek,nonce);
      const payload=Buffer.concat([Buffer.from(JSON.stringify({title,body,url:'/'})),Buffer.from([2])]);
      const ciphertext=Buffer.concat([cipher.update(payload),cipher.final(),cipher.getAuthTag()]);
      const recordSize=Buffer.alloc(4);recordSize.writeUInt32BE(4096,0);
      const message=Buffer.concat([salt,recordSize,Buffer.from([senderPub.length]),senderPub,ciphertext]);
      const now=Math.floor(Date.now()/1000);
      const unsigned=b64(JSON.stringify({typ:'JWT',alg:'ES256'}))+'.'+b64(JSON.stringify({aud:target.origin,exp:now+12*3600,sub:vapidSubject}));
      const signature=crypto.sign('sha256',Buffer.from(unsigned),{key:vapidPriv,dsaEncoding:'ieee-p1363'});
      const token=unsigned+'.'+b64(signature);
      const res=await fetch(sub.endpoint,{method:'POST',headers:{'Authorization':`vapid t=${token}, k=${db.vapid.publicKey}`,
        'TTL':'86400','Content-Encoding':'aes128gcm','Content-Type':'application/octet-stream'},body:message,signal:AbortSignal.timeout(12000)});
      if(res.status===404||res.status===410)removed.push(sub.endpoint);
      else if(!res.ok)console.warn('Push service returned:',res.status);
    }catch(e){console.warn('Push unavailable:',e.message);}
  }
  if(removed.length){u.pushSubscriptions=u.pushSubscriptions.filter(x=>!removed.includes(x.endpoint));persist();}
}

const cleanName = s => (String(s || '').trim().toLowerCase());
const response = (res,status,data) => {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(JSON.stringify(data));
};
const error = (res,status,msg) => response(res,status,{error:msg});
const myPublicUser = u => ({username:u.username,displayName:u.displayName,joinedAt:u.joinedAt,stats:u.stats,stars:u.stars||0,powerUps:u.powerUps||{eliminate:0,hotcold:0,fifty:0},unlockedHomes:u.unlockedHomes||['starter']});
function getUser(req) {
  const match = /^Bearer ([a-f0-9]{64})$/.exec(req.headers.authorization||'');
  if(!match) return null;
  return Object.values(db.users).find(x => x.token === match[1]) || null;
}
function projectMatch(m,who) {
  const isHider = m.hider === who;
  const safe = {id:m.id,players:m.players,hider:m.hider,seeker:m.seeker,role:isHider?'hide':'seek',
    opponent: isHider?m.seeker:m.hider,phase:m.phase,createdAt:m.createdAt,houseId:m.houseId||'starter',turnDeadline:m.turnDeadline||null,
    hideStartedAt:m.hideStartedAt,seekStartedAt:m.seekStartedAt,endedAt:m.endedAt,
    winner:m.winner,result:m.result,searches:m.searches||0,lastSearchAt:m.lastSearchAt||null,
    powerUsed:!isHider&&!!m.powerUsed,eliminatedRooms:isHider?[]:(m.eliminatedRooms||[]),hotColdUntil:isHider?0:(m.hotColdUntil||0),mySpot:isHider?m.spotId:null,starsAwarded:m.starsAwarded||0};
  if(m.phase==='finished') safe.finalSpot=m.spotId;
  return safe;
}
function finish(m,winner,result) {
  if(m.phase === 'finished') return;
  m.phase='finished';m.winner=winner;m.result=result;m.endedAt=Date.now();
  for(const name of m.players) {
    const s=db.users[name].stats;
    s.games++; if(name===winner) s.wins++; else s.losses++;
  }
  const winnerUser=db.users[winner];
  if(result==='forfeit') {
    // A player can receive stars from forfeits at most once per UTC calendar day.
    // Other forfeits remain valid wins in statistics but don't generate extra stars.
    if(winnerUser.lastForfeitStarDay!==utcDay(m.endedAt)) {
      winnerUser.stars=(winnerUser.stars||0)+100;
      winnerUser.lastForfeitStarDay=utcDay(m.endedAt);
      m.starsAwarded=100;
    } else m.starsAwarded=0;
  } else {
    winnerUser.stars=(winnerUser.stars||0)+100;
    m.starsAwarded=100;
  }
  db.users[m.hider].stats.hides++;
  db.users[m.seeker].stats.seeks++;
  if(winner===m.hider) db.users[m.hider].stats.escapes++;
  else db.users[m.seeker].stats.finds++;
  persist();scheduleDeadline(m);
  for(const name of m.players){const player=db.users[name];void sendPush(player,'Round complete!',winner===name?'You won your Hide & Seek match!':'Your Hide & Seek match has ended.');}
}
const scheduledDeadlines=new Map();
function scheduleDeadline(m){
  if(scheduledDeadlines.has(m.id)){clearTimeout(scheduledDeadlines.get(m.id));scheduledDeadlines.delete(m.id);}
  if(m.phase==='finished')return;
  const activeClock=m.phase==='awaiting_hide'&&m.hideStartedAt?m.hideStartedAt+HIDE_MS:
    m.phase==='awaiting_seek'&&m.seekStartedAt?m.seekStartedAt+SEEK_MS:null;
  const deadline=Math.min(m.turnDeadline||Infinity,activeClock||Infinity);
  if(!Number.isFinite(deadline))return;
  const timer=setTimeout(()=>{scheduledDeadlines.delete(m.id);resolveDeadlines(m);scheduleDeadline(m);},Math.max(10,deadline-Date.now()+10));
  timer.unref();scheduledDeadlines.set(m.id,timer);
}
function resolveDeadlines(m){
  if(m.phase==='finished')return;
  const now=Date.now();
  if(m.turnDeadline && now>=m.turnDeadline) {
    const absent=m.phase==='awaiting_hide'?m.hider:m.seeker;
    finish(m,m.players.find(x=>x!==absent),'forfeit');
    return;
  }
  if(m.phase==='awaiting_hide' && m.hideStartedAt && now>=m.hideStartedAt+HIDE_MS){
    m.spotId=m.spotId||Array.from(VALID_SPOTS)[crypto.randomInt(VALID_SPOTS.size)];
    m.phase='awaiting_seek';m.turnDeadline=now+TURN_LIMIT;persist();
    void sendPush(db.users[m.seeker],'Your turn to seek!','Your 24-hour turn window is open.');
  }
  if(m.phase==='awaiting_seek' && m.seekStartedAt && now>=m.seekStartedAt+SEEK_MS)finish(m,m.hider,'escaped');
}
async function readBody(req) {
  let raw='';
  for await (const chunk of req) {
    raw+=chunk;
    if(raw.length>16000) throw new Error('Request too large');
  }
  try{return raw?JSON.parse(raw):{};}catch{return {};}
}
function loginResponse(res,u) {return response(res,200,{token:u.token,user:myPublicUser(u)});}
function endpoint(req,res,url,body) {
  const route=url.pathname;
  if(req.method==='GET' && route==='/api/status') return response(res,200,{ok:true,version:'0.1.0'});
  if(req.method==='POST' && route==='/api/register') {
    const username=cleanName(body.username), pass=String(body.password||'');
    const displayName=String(body.displayName||username).trim().slice(0,26);
    if(!/^[a-z0-9_]{3,18}$/.test(username)) return error(res,400,'Username must be 3–18 letters, numbers or underscores.');
    if(pass.length<6 || pass.length>100) return error(res,400,'Password must be at least 6 characters.');
    if(db.users[username]) return error(res,409,'That username is taken.');
    const salt=secret(), passwordHash=crypto.scryptSync(pass,salt,64).toString('hex');
    const u={username,displayName,joinedAt:Date.now(),salt,passwordHash,token:secret(),stars:0,powerUps:{eliminate:0,hotcold:0,fifty:0},unlockedHomes:['starter'],stats:{games:0,wins:0,losses:0,hides:0,escapes:0,seeks:0,finds:0}};
    db.users[username]=u;persist();return loginResponse(res,u);
  }
  if(req.method==='POST' && route==='/api/login') {
    const u=db.users[cleanName(body.username)];
    if(!u) return error(res,401,'Invalid username or password.');
    const supplied=crypto.scryptSync(String(body.password||''),u.salt,64);
    if(!crypto.timingSafeEqual(supplied,Buffer.from(u.passwordHash,'hex'))) return error(res,401,'Invalid username or password.');
    u.token=secret();persist();return loginResponse(res,u);
  }
  const u=getUser(req);
  if(!u) return error(res,401,'Sign in to continue.');
  if(req.method==='GET' && route==='/api/push/key') return response(res,200,{enabled:!!vapidSubject,key:db.vapid.publicKey});
  if(req.method==='POST' && route==='/api/push/subscribe') {
    if(!vapidSubject)return error(res,503,'Device push is not configured on this server.');
    const s=body.subscription;
    if(!s||typeof s.endpoint!=='string'||!s.endpoint.startsWith('https://')||s.endpoint.length>1600||
       !/^[A-Za-z0-9_\-+=/]{40,180}$/.test(s.keys?.p256dh||'')||
       !/^[A-Za-z0-9_\-+=/]{12,60}$/.test(s.keys?.auth||'')) return error(res,400,'Invalid push subscription.');
    u.pushSubscriptions=u.pushSubscriptions||[];
    u.pushSubscriptions=u.pushSubscriptions.filter(x=>x.endpoint!==s.endpoint);
    u.pushSubscriptions.push({endpoint:s.endpoint,keys:{p256dh:s.keys.p256dh,auth:s.keys.auth}});
    u.pushSubscriptions=u.pushSubscriptions.slice(-6);persist();
    return response(res,200,{subscribed:true});
  }
  if(req.method==='GET' && route==='/api/state') {
    for(const m of db.matches) resolveDeadlines(m);
    const matches=db.matches.filter(m=>m.players.includes(u.username)).sort((a,b)=>b.createdAt-a.createdAt).slice(0,60).map(m=>projectMatch(m,u.username));
    const leaderboard=Object.values(db.users).map(myPublicUser).sort((a,b)=>b.stats.wins-a.stats.wins || b.stats.games-a.stats.games).slice(0,25);
    return response(res,200,{user:myPublicUser(u),matches,leaderboard,playerCount:Object.keys(db.users).length});
  }
  if(req.method==='GET' && route.startsWith('/api/players/')) {
    const target=db.users[cleanName(decodeURIComponent(route.split('/').pop()))];
    if(!target) return error(res,404,'Player not found.');
    return response(res,200,{player:myPublicUser(target)});
  }
  if(req.method==='POST' && route==='/api/powerups/buy') {
    const pack=POWER_PACKS[body.type];
    if(!pack)return error(res,400,'Unknown power-up.');
    if((u.stars||0)<pack.cost)return error(res,409,'Not enough stars.');
    u.stars-=pack.cost;u.powerUps ||= {eliminate:0,hotcold:0,fifty:0};
    u.powerUps[body.type]=(u.powerUps[body.type]||0)+pack.quantity;persist();
    return response(res,200,{user:myPublicUser(u)});
  }
  if(req.method==='POST' && route==='/api/matches') {
    if(db.matches.filter(m=>m.players.includes(u.username)&&m.phase!=='finished').length>=15) return error(res,409,'Finish your active games before starting more challenges.');
    if(body.houseId!==HOUSE_ID)return error(res,400,'This house is not available yet. Select the Starter Home.');
    let other;
    if(body.type==='friend') {
      other=db.users[cleanName(body.username)];
      if(!other) return error(res,404,'Friend not found. Ask them to create a player account first.');
      if(!(other.unlockedHomes||['starter']).includes(body.houseId))return error(res,409,'Your friend has not unlocked this house.');
    } else if(body.type==='random') {
      const pool=Object.values(db.users).filter(x=>x.username!==u.username && (x.unlockedHomes||['starter']).includes(body.houseId) &&
        db.matches.filter(m=>m.players.includes(x.username)&&m.phase!=='finished').length<15);
      if(!pool.length) return error(res,404,'No other registered players yet. Invite a friend or try the demo.');
      other=pool[crypto.randomInt(pool.length)];
    } else return error(res,400,'Select random or friend.');
    if(other.username===u.username) return error(res,400,'You cannot challenge yourself.');
    const hider=crypto.randomInt(2)===0?u.username:other.username;
    const m={id:crypto.randomUUID(),players:[u.username,other.username],hider,
      seeker:hider===u.username?other.username:u.username,phase:'awaiting_hide',
      createdAt:Date.now(),turnDeadline:Date.now()+TURN_LIMIT,houseId:body.houseId,hideStartedAt:null,seekStartedAt:null,endedAt:null,spotId:null,
      winner:null,result:null,searches:0,lastSearchAt:null};
    db.matches.push(m);persist();
    void sendPush(other,'New Hush House challenge',`${u.displayName} challenged you! Open the game to see your role.`);
    return response(res,201,{match:projectMatch(m,u.username)});
  }
  const matchRoute=/^\/api\/matches\/([a-f0-9-]+)(?:\/(start|hide|search|powerup|temperature))?$/.exec(route);
  if(matchRoute) {
    const m=db.matches.find(x=>x.id===matchRoute[1] && x.players.includes(u.username));
    if(!m) return error(res,404,'Game not found.');
    resolveDeadlines(m);
    const action=matchRoute[2];
    if(req.method==='GET'&&!action) return response(res,200,{match:projectMatch(m,u.username)});
    if(req.method!=='POST') return error(res,405,'Method not allowed.');
    if(action==='start') {
      if(u.username===m.hider && m.phase==='awaiting_hide'&&!m.hideStartedAt) {m.hideStartedAt=Date.now();persist();scheduleDeadline(m);}
      if(u.username===m.seeker && m.phase==='awaiting_seek'&&!m.seekStartedAt) {m.seekStartedAt=Date.now();persist();scheduleDeadline(m);}
      return response(res,200,{match:projectMatch(m,u.username)});
    }
    if(action==='hide') {
      if(u.username!==m.hider||m.phase!=='awaiting_hide') return error(res,409,'It is not your turn to hide.');
      if(!m.hideStartedAt) return error(res,409,'Start your hiding turn first.');
      if(!VALID_SPOTS.has(body.spotId)) return error(res,400,'Unknown hiding spot.');
      m.spotId=body.spotId;m.phase='awaiting_seek';m.turnDeadline=Date.now()+TURN_LIMIT;persist();scheduleDeadline(m);
      void sendPush(db.users[m.seeker],'Your turn to seek!',`${db.users[m.hider].displayName} has hidden. Your 24-hour seeking turn is ready.`);
      return response(res,200,{match:projectMatch(m,u.username)});
    }
    if(action==='powerup') {
      if(u.username!==m.seeker||m.phase!=='awaiting_seek'||!m.seekStartedAt)return error(res,409,'Power-ups are for the active seeker.');
      if(m.powerUsed)return error(res,409,'Only one power-up may be used per round.');
      const type=body.type;if(!POWER_PACKS[type])return error(res,400,'Unknown power-up.');
      u.powerUps ||= {eliminate:0,hotcold:0,fifty:0};
      if(!(u.powerUps[type]>0))return error(res,409,'Buy this power-up first.');
      if(type==='eliminate') {
        m.eliminatedRooms ||= [];
        const actual=SPOT_DATA[m.spotId]?.room;
        const available=ROOMS.filter(r=>r!==actual&&!m.eliminatedRooms.includes(r));
        if(!available.length)return error(res,409,'All incorrect rooms have already been eliminated.');
        u.powerUps[type]--;m.powerUsed=true;
        const room=available[crypto.randomInt(available.length)];m.eliminatedRooms.push(room);persist();
        return response(res,200,{room,match:projectMatch(m,u.username),user:myPublicUser(u)});
      }
      if(type==='hotcold') {
        if(m.hotColdUntil && m.hotColdUntil>Date.now())return error(res,409,'Hot/Cold is already active.');
        u.powerUps[type]--;m.powerUsed=true;m.hotColdUntil=Date.now()+10000;persist();
        return response(res,200,{until:m.hotColdUntil,match:projectMatch(m,u.username),user:myPublicUser(u)});
      }
      if(type==='fifty') {
        if(!ROOMS.includes(body.room))return error(res,400,'Select a valid room.');
        u.powerUps[type]--;m.powerUsed=true;
        const correct=SPOT_DATA[m.spotId]?.room===body.room;
        finish(m,correct?m.seeker:m.hider,'fifty');persist();
        return response(res,200,{correct,match:projectMatch(m,u.username),user:myPublicUser(u)});
      }
    }
    if(action==='temperature') {
      if(req.method!=='POST'||u.username!==m.seeker||m.phase!=='awaiting_seek'||!m.seekStartedAt)return error(res,409,'Not seeking.');
      if(!m.hotColdUntil||Date.now()>m.hotColdUntil)return response(res,200,{expired:true});
      const x=Number(body.x),z=Number(body.z),loc=SPOT_DATA[m.spotId];
      if(!Number.isFinite(x)||!Number.isFinite(z)||x<0||x>36||z<0||z>24)return error(res,400,'Invalid position.');
      const distance=Math.hypot(loc.x-x,loc.z-z);
      return response(res,200,{heat:Math.max(0,Math.min(100,Math.round(100-distance*5))),until:m.hotColdUntil});
    }
    if(action==='search') {
      if(u.username!==m.seeker || m.phase!=='awaiting_seek' || !m.seekStartedAt) return error(res,409,'It is not your turn to seek.');
      if(!VALID_SPOTS.has(body.spotId)) return error(res,400,'Unknown search target.');
      if(m.lastSearchAt && Date.now()-m.lastSearchAt<950) return error(res,429,'Try another search in a moment.');
      m.lastSearchAt=Date.now();m.searches++;
      const found=m.spotId===body.spotId;
      if(found) finish(m,m.seeker,'found'); else persist();
      return response(res,200,{found,match:projectMatch(m,u.username)});
    }
    return error(res,404,'Unknown action.');
  }
  return error(res,404,'Endpoint not found.');
}
const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8',
  '.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png',
  '.webmanifest':'application/manifest+json'};
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  if(url.pathname.startsWith('/api/')) {
    try {return endpoint(req,res,url,req.method==='POST'?await readBody(req):{});}
    catch(e){console.error(e);return error(res,500,'Unexpected server error.');}
  }
  const rel=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
  const filename=path.resolve(ROOT,'.'+rel);
  if(!filename.startsWith(ROOT+path.sep)) {res.writeHead(403);return res.end('Forbidden');}
  fs.readFile(filename,(err,file)=>{
    if(err){res.writeHead(404);return res.end('Not found');}
    res.writeHead(200,{'Content-Type':types[path.extname(filename)]||'application/octet-stream',
      'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(file);
  });
});
for(const m of db.matches){resolveDeadlines(m);scheduleDeadline(m)}
server.listen(PORT,()=>console.log(`Hush House ready → http://localhost:${PORT}`));
