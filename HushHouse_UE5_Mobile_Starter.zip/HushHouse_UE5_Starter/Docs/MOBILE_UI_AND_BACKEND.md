# Next development tasks

## Mobile HUD (not yet implemented)
Create `WBP_HUD` in UMG. Bind widgets to `AHHGameMode` for role, timer, nearest hide spot, stars, and status. Place `UsePowerUp(Type,RoomGuess)` behind a lightning-bolt selector; only one activation allowed per seeking round. Add a dismissible X button. Use touch virtual joysticks for move/look and a SEARCH/HIDE button for Interact. Replace old axis bindings with Enhanced Input before release.

## Persistence and multiplayer (not yet implemented)
Existing Node backend from the previous browser project is in `LegacyBackend/`. Its API/JSON schema can be adapted to a UE HTTP client. Do not award stars on the mobile client; authoritative game results, inventory, daily forfeits, 24h deadlines, and star purchase validations belong on the server. Add secure auth token storage, request retries, network reconnect, and server verification of moves and search attempts. Current Unreal GameMode is **single-device practice only**, using a simulated hidden location.

## Level and props
The generated starter level uses engine cubes to represent floor, solid walls, door openings and major furniture footprints. Spawned searchable spots are invisible. Use `Editor/import_glb.py` to bring in the first three textured pieces, align them and disable/replace the corresponding blockout furniture by tag. Add rest of props in stages and build materials using imported color/roughness/normal texture maps. Existing textures are illustrative diffuse maps and not a full baked PBR set.

## Collision tests
Verify capsule radius=29 cm, height=166 cm, eye height (capsule center +61 cm), ~2.48m wide door openings. Test door-to-door circulation and furniture obstacles with UE collision overlays. Use mobile profiler before increasing polygon count.
