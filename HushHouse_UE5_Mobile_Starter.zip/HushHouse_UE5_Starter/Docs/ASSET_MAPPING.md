# Source-of-truth asset mapping

Input GLB assets from the existing Hush House browser prototype:

- `ImportAssets/sectional.glb` -> Living Room sectional, intended at world x=4.45m, y=9.05m.
- `ImportAssets/bed.glb` -> Bedroom bed, intended at x=5.95m, y=18.25m.
- `ImportAssets/island.glb` -> Kitchen island, intended at x=18.4m, y=8.25m.
- Four texture images: `fabric.png`, `wood.png`, `metal.png`, `stone.png`.

Coordinate conversion: original web x,z -> Unreal X,Y in centimeters (`* 100`). Original world height -> Unreal Z in centimeters (`* 100`). Verify +Y orientation and pivot offsets during import; do not assume authored GLB pivots match runtime blockout positions. Keep imported furniture's collision inside the visible mesh footprint. Use simple custom collision rather than per-triangle mobile collision.

All 46 hiding spots are preserved in `Content/Data/starter_spots.json`.

**Important:** Prototype JSON and imported files are ready; the `.uasset` conversions, final meshes/material instances, baked lighting, LODs, animation blueprints, and shipping-quality PBR have to be generated and inspected in Unreal Editor.
