using UnrealBuildTool;
public class HushHouseEditorTarget : TargetRules { public HushHouseEditorTarget(TargetInfo Target) : base(Target) { Type = TargetType.Editor; DefaultBuildSettings = BuildSettingsVersion.V5; ExtraModuleNames.Add("HushHouse"); } }
