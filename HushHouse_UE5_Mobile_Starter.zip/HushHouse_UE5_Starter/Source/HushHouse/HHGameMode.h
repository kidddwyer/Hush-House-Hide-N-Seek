#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "HHGameMode.generated.h"
class AHHSpot;
UENUM(BlueprintType) enum class EHHRoundState:uint8 {Menu, Hiding, Seeking, Finished};
UCLASS()
class HUSHHOUSE_API AHHGameMode : public AGameModeBase
{
 GENERATED_BODY()
public:
 AHHGameMode();
 virtual void BeginPlay() override;
 virtual void Tick(float DeltaSeconds) override;
 UPROPERTY(BlueprintReadOnly) EHHRoundState RoundState=EHHRoundState::Menu;
 UPROPERTY(BlueprintReadOnly) float SecondsRemaining=0.f;
 UPROPERTY(BlueprintReadOnly) bool bPowerUsed=false;
 UPROPERTY(BlueprintReadOnly) int32 Stars=0;
 UPROPERTY(BlueprintReadOnly) bool bLastRoundWon=false;
 UPROPERTY(BlueprintReadOnly) FString Feedback;
 UPROPERTY(BlueprintReadOnly) TArray<FString> EliminatedRooms;
 UPROPERTY(BlueprintReadOnly) float HotColdRemaining=0.f;
 UPROPERTY(BlueprintReadOnly) float HeatPercent=0.f;
 UPROPERTY(BlueprintReadOnly) TMap<FString,int32> PowerInventory;
 UFUNCTION(BlueprintCallable) void BeginPractice(bool bPlayerSeeking);
 UFUNCTION(BlueprintCallable) void InteractAt(AHHSpot* Spot);
 UFUNCTION(BlueprintCallable) bool UsePowerUp(const FString& Type,const FString& GuessRoom);
 UFUNCTION(BlueprintPure) FString CurrentRoom() const;
 UFUNCTION(BlueprintPure) FString HiddenSpotId() const {return HiddenSpot;}
private:
 FString HiddenSpot;
 bool bIsPractice=true;
 void Finish(bool bWin);
};
