#include "HHCharacter.h"
#include "HHSpot.h"
#include "HHGameMode.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
AHHCharacter::AHHCharacter()
{
 PrimaryActorTick.bCanEverTick=true;
 GetCapsuleComponent()->InitCapsuleSize(29.f,83.f);
 GetCharacterMovement()->MaxWalkSpeed=365.f;
 GetCharacterMovement()->MaxStepHeight=22.f;
 bUseControllerRotationYaw=true;
 GetCharacterMovement()->bOrientRotationToMovement=false;
 EyeCamera=CreateDefaultSubobject<UCameraComponent>(TEXT("EyeCamera"));
 EyeCamera->SetupAttachment(GetCapsuleComponent());EyeCamera->SetRelativeLocation(FVector(0,0,61));
 EyeCamera->bUsePawnControlRotation=true;EyeCamera->SetFieldOfView(85.f);
}
void AHHCharacter::Tick(float DeltaSeconds){Super::Tick(DeltaSeconds);}
void AHHCharacter::SetupPlayerInputComponent(UInputComponent* Input)
{
 Super::SetupPlayerInputComponent(Input);
 Input->BindAxis("MoveForward",this,&AHHCharacter::MoveForward);
 Input->BindAxis("MoveRight",this,&AHHCharacter::MoveRight);
 Input->BindAxis("Turn",this,&AHHCharacter::LookYaw);
 Input->BindAxis("LookUp",this,&AHHCharacter::LookPitch);
 Input->BindAction("Interact",IE_Pressed,this,&AHHCharacter::Interact);
}
void AHHCharacter::MoveForward(float V){if(Controller&&V!=0)AddMovementInput(GetActorForwardVector(),V);}
void AHHCharacter::MoveRight(float V){if(Controller&&V!=0)AddMovementInput(GetActorRightVector(),V);}
void AHHCharacter::LookYaw(float V){AddControllerYawInput(V);}
void AHHCharacter::LookPitch(float V){AddControllerPitchInput(V);}
AHHSpot* AHHCharacter::NearestSpot(float MaxDistance) const
{
 AHHSpot* Best=nullptr;float Min=MaxDistance;
 const FVector Forward=EyeCamera->GetForwardVector();
 for(TActorIterator<AHHSpot> It(GetWorld());It;++It)
 {
  FVector To=It->GetActorLocation()-GetActorLocation();To.Z=0;
  const float Distance=To.Size();
  if(Distance>Min||Distance<1.f)continue;
  if(FVector::DotProduct(Forward.GetSafeNormal2D(),To.GetSafeNormal())<.25f)continue;
  Min=Distance;Best=*It;
 }
 return Best;
}
void AHHCharacter::Interact()
{
 if(AHHGameMode* GM=GetWorld()->GetAuthGameMode<AHHGameMode>())GM->InteractAt(NearestSpot());
}
void AHHCharacter::UsePowerUp(const FString& Type,const FString& RoomGuess)
{
 if(AHHGameMode* GM=GetWorld()->GetAuthGameMode<AHHGameMode>())GM->UsePowerUp(Type,RoomGuess);
}
