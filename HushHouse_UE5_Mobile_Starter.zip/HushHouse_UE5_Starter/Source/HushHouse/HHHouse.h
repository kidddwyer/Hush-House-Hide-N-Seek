#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "HHHouse.generated.h"
UCLASS()
class HUSHHOUSE_API AHHHouse : public AActor
{
 GENERATED_BODY()
public:
 AHHHouse();
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Level") bool bGenerateOnBeginPlay=true;
 virtual void BeginPlay() override;
 UFUNCTION(CallInEditor,BlueprintCallable) void GenerateHouse();
private:
 UPROPERTY() TArray<TObjectPtr<AActor>> GeneratedActors;
 class AStaticMeshActor* AddBlock(const FVector& Pos,const FVector& Extent,const FLinearColor& Tint,const FString& Tag,bool bCollision=true);
 void WallX(float Y,float From,float To,const FLinearColor& Color);
 void WallY(float X,float From,float To,const FLinearColor& Color);
 void DoorX(float Y,float A,float B,float Door,const FLinearColor& C);
 void DoorY(float X,float A,float B,float Door,const FLinearColor& C);
};
