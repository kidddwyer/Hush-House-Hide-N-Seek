#include "HHHouse.h"
#include "HHSpot.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMeshActor.h"
#include "Kismet/GameplayStatics.h"
#include "UObject/ConstructorHelpers.h"
#include "Engine/World.h"
#include "Engine/CollisionProfile.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
AHHHouse::AHHHouse(){PrimaryActorTick.bCanEverTick=false;}
void AHHHouse::BeginPlay(){Super::BeginPlay();if(bGenerateOnBeginPlay)GenerateHouse();}
AStaticMeshActor* AHHHouse::AddBlock(const FVector& P,const FVector& Extent,const FLinearColor& Tint,const FString& Tag,bool Solid)
{
 UStaticMesh* Cube=LoadObject<UStaticMesh>(nullptr,TEXT("/Engine/BasicShapes/Cube.Cube"));
 if(!Cube)return nullptr;
 AStaticMeshActor* A=GetWorld()->SpawnActor<AStaticMeshActor>(P,FRotator::ZeroRotator);
 if(!A)return nullptr;
 A->GetStaticMeshComponent()->SetStaticMesh(Cube);
 A->SetActorScale3D(Extent/100.f);
 A->GetStaticMeshComponent()->SetMobility(EComponentMobility::Movable);
 A->GetStaticMeshComponent()->SetCollisionEnabled(Solid?ECollisionEnabled::QueryAndPhysics:ECollisionEnabled::NoCollision);
 A->Tags.Add(FName(*Tag));GeneratedActors.Add(A);
 // Tint labels are stored for material-authoring/import pass; mesh uses engine starter material.
 return A;
}
void AHHHouse::WallX(float Y,float A,float B,const FLinearColor& C){if(B>A)AddBlock(FVector((A+B)*50.f,Y*100.f,171.f),FVector((B-A)*100.f,24.f,342.f),C,TEXT("Wall"));}
void AHHHouse::WallY(float X,float A,float B,const FLinearColor& C){if(B>A)AddBlock(FVector(X*100.f,(A+B)*50.f,171.f),FVector(24.f,(B-A)*100.f,342.f),C,TEXT("Wall"));}
void AHHHouse::DoorX(float Y,float A,float B,float Door,const FLinearColor& C)
{
 WallX(Y,A,Door-1.24f,C);WallX(Y,Door+1.24f,B,C);
 AddBlock(FVector(Door*100.f,Y*100.f,317.f),FVector(248.f,26.f,50.f),C,TEXT("Header"));
}
void AHHHouse::DoorY(float X,float A,float B,float Door,const FLinearColor& C)
{
 WallY(X,A,Door-1.24f,C);WallY(X,Door+1.24f,B,C);
 AddBlock(FVector(X*100.f,Door*100.f,317.f),FVector(26.f,248.f,50.f),C,TEXT("Header"));
}
void AHHHouse::GenerateHouse()
{
 if(!GetWorld())return;
 for(AActor* A:GeneratedActors)if(IsValid(A))A->Destroy();GeneratedActors.Reset();
 const FLinearColor Coral(.95f,.72f,.69f),Sage(.72f,.83f,.73f),Blue(.44f,.65f,.92f),Lavender(.76f,.70f,.90f),Mint(.71f,.89f,.85f);
 for(int R=0;R<2;++R)for(int C=0;C<3;++C)
 {
  if(R==1&&C==2)continue;
  const FLinearColor Shade=R==0?(C==0?Coral:(C==1?Sage:Blue)):(C==0?Lavender:Mint);
  AddBlock(FVector((C*12+6)*100.f,(R*12+6)*100.f,-16.f),FVector(1176.f,1176.f,32.f),Shade,TEXT("Floor"));
 }
 // Same five connected room footprint as the HTML version. Wide door voids are genuine geometry.
 WallX(0,0,36,Coral);WallX(24,0,24,Mint);WallY(0,0,24,Lavender);WallY(36,0,12,Blue);
 DoorY(12,0,12,6,Coral);DoorY(24,0,12,6,Sage);DoorY(12,12,24,17.5f,Lavender);WallY(24,12,24,Mint);
 DoorX(12,0,12,6,Coral);DoorX(12,12,24,18,Sage);WallX(12,24,36,Blue);
 // Rebuilt blockout furniture: replace by imported PBR StaticMeshes within Unreal Editor.
 auto Furn=[this](float X,float Y,float W,float D,float H,const FLinearColor& C,const TCHAR* T){AddBlock(FVector(X*100,Y*100,H*50),FVector(W*100,D*100,H*100),C,T);};
 Furn(4.45f,9.05f,3.6f,1.f,.75f,Coral,TEXT("Sectional"));Furn(2.28f,8.46f,1.f,2.1f,.75f,Coral,TEXT("Chaise"));
 Furn(4.95f,1.75f,4.6f,.72f,.8f,Coral,TEXT("MediaConsole"));Furn(5.65f,6.95f,1.6f,.9f,.52f,Coral,TEXT("CoffeeTable"));
 Furn(18.4f,8.25f,4.12f,1.5f,1.08f,Sage,TEXT("Island"));Furn(18.6f,3.18f,5.6f,1.08f,1.05f,Sage,TEXT("KitchenCabinets"));
 Furn(29.7f,6.05f,2.85f,4.65f,1.45f,Blue,TEXT("SUV"));
 Furn(5.95f,18.25f,3.55f,4.55f,1.0f,Lavender,TEXT("Bed"));
 Furn(20.35f,13.75f,4.95f,1.05f,1.2f,Mint,TEXT("Vanity"));Furn(15.5f,20.5f,4.1f,1.9f,.85f,Mint,TEXT("Tub"));
 // Hiding/search location dataset is cooked as a loose NonUFS JSON file via packaging config.
 FString Raw; const FString JsonPath=FPaths::Combine(FPaths::ProjectContentDir(),TEXT("Data/starter_spots.json"));
 if(!FFileHelper::LoadFileToString(Raw,*JsonPath)){UE_LOG(LogTemp,Warning,TEXT("Missing hide spot data: %s"),*JsonPath);return;}
 TArray<TSharedPtr<FJsonValue>> Entries;
 if(!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Raw),Entries))return;
 for(const auto& Entry:Entries)
 {
  const TSharedPtr<FJsonObject> O=Entry->AsObject();if(!O)continue;
  AHHSpot* Spot=GetWorld()->SpawnActor<AHHSpot>(FVector(O->GetNumberField(TEXT("x"))*100.f,O->GetNumberField(TEXT("z"))*100.f,95.f),FRotator::ZeroRotator);
  if(Spot){Spot->SpotId=O->GetStringField(TEXT("id"));Spot->DisplayName=O->GetStringField(TEXT("name"));Spot->RoomName=O->GetStringField(TEXT("room"));GeneratedActors.Add(Spot);}
 }
}
