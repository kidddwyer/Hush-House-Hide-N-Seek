#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "HHCharacter.generated.h"
UCLASS()
class HUSHHOUSE_API AHHCharacter : public ACharacter
{
 GENERATED_BODY()
public:
 AHHCharacter();
 virtual void SetupPlayerInputComponent(class UInputComponent* Input) override;
 virtual void Tick(float DeltaSeconds) override;
 UFUNCTION(BlueprintCallable) void MoveForward(float Value);
 UFUNCTION(BlueprintCallable) void MoveRight(float Value);
 UFUNCTION(BlueprintCallable) void LookYaw(float Value);
 UFUNCTION(BlueprintCallable) void LookPitch(float Value);
 UFUNCTION(BlueprintCallable) void Interact();
 UFUNCTION(BlueprintCallable) void UsePowerUp(const FString& Type,const FString& RoomGuess);
 UFUNCTION(BlueprintPure) class AHHSpot* NearestSpot(float MaxDistance=280.f) const;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly) TObjectPtr<class UCameraComponent> EyeCamera;
};
