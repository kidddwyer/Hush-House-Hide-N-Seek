#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "HHSpot.generated.h"
UCLASS()
class HUSHHOUSE_API AHHSpot : public AActor
{
 GENERATED_BODY()
public:
 AHHSpot();
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Hide Spot") FString SpotId;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Hide Spot") FString DisplayName;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Hide Spot") FString RoomName;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly) TObjectPtr<class USphereComponent> Area;
};
