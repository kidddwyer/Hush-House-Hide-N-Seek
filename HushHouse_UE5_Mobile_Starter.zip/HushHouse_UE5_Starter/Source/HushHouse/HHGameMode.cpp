#include "HHGameMode.h"
#include "HHCharacter.h"
#include "HHSpot.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
AHHGameMode::AHHGameMode(){DefaultPawnClass=AHHCharacter::StaticClass();PrimaryActorTick.bCanEverTick=true;PowerInventory.Add(TEXT("eliminate"),2);PowerInventory.Add(TEXT("hotcold"),2);PowerInventory.Add(TEXT("fifty"),1);}
void AHHGameMode::BeginPlay(){Super::BeginPlay();}
void AHHGameMode::Tick(float DeltaSeconds)
{
 Super::Tick(DeltaSeconds);
 if(RoundState!=EHHRoundState::Hiding&&RoundState!=EHHRoundState::Seeking)return;
 SecondsRemaining=FMath::Max(0.f,SecondsRemaining-DeltaSeconds);
 if(HotColdRemaining>0.f)
 {
  HotColdRemaining=FMath::Max(0.f,HotColdRemaining-DeltaSeconds);
  for(TActorIterator<AHHSpot> It(GetWorld());It;++It)if(It->SpotId==HiddenSpot)
  {
   const APawn* P=UGameplayStatics::GetPlayerPawn(this,0);
   if(P)HeatPercent=FMath::Clamp(100.f-FVector::Dist2D(P->GetActorLocation(),It->GetActorLocation())/100.f*5.f,0.f,100.f);
   break;
  }
 }
 if(SecondsRemaining<=0.f)
 {
  if(RoundState==EHHRoundState::Hiding){Feedback=TEXT("Hide timer expired");RoundState=EHHRoundState::Seeking;SecondsRemaining=180.f;}
  else Finish(false);
 }
}
void AHHGameMode::BeginPractice(bool bPlayerSeeking)
{
 bPowerUsed=false;EliminatedRooms.Reset();HotColdRemaining=0;HeatPercent=0;Feedback=TEXT("Find a hiding place");HiddenSpot.Empty();bIsPractice=true;
 TArray<AHHSpot*> All;
 for(TActorIterator<AHHSpot> It(GetWorld());It;++It)All.Add(*It);
 if(bPlayerSeeking){if(All.Num())HiddenSpot=All[FMath::RandRange(0,All.Num()-1)]->SpotId;RoundState=EHHRoundState::Seeking;SecondsRemaining=180.f;Feedback=TEXT("Find the hidden player");}
 else{RoundState=EHHRoundState::Hiding;SecondsRemaining=90.f;}
}
void AHHGameMode::InteractAt(AHHSpot* Spot)
{
 if(RoundState==EHHRoundState::Hiding)
 {
  if(!Spot){Feedback=TEXT("Approach a hiding place");return;}
  HiddenSpot=Spot->SpotId;Feedback=FString::Printf(TEXT("Hiding: %s"),*Spot->DisplayName);RoundState=EHHRoundState::Finished;return;
 }
 if(RoundState==EHHRoundState::Seeking)
 {
  if(!Spot){Feedback=TEXT("Nobody here. Keep looking!");return;}
  if(Spot->SpotId==HiddenSpot){Feedback=TEXT("YOU FOUND ME!");Finish(true);}
  else Feedback=TEXT("Nobody here. Keep looking!");
 }
}
void AHHGameMode::Finish(bool bWin)
{
 bLastRoundWon=bWin;RoundState=EHHRoundState::Finished;SecondsRemaining=0;
 Feedback=bWin?TEXT("YOU FOUND ME! Practice victory"):TEXT("Time expired. Hider escaped");
 // Server-authoritative star rewards will be integrated through the backend. Practice awards none.
}
FString AHHGameMode::CurrentRoom()const
{
 const APawn* P=UGameplayStatics::GetPlayerPawn(this,0);if(!P)return TEXT("Unknown");
 const FVector Pos=P->GetActorLocation();const int32 Col=FMath::FloorToInt(Pos.X/1200.f),Row=FMath::FloorToInt(Pos.Y/1200.f);
 if(Row==0){if(Col==0)return TEXT("Living Room");if(Col==1)return TEXT("Kitchen");if(Col==2)return TEXT("Garage");}
 if(Row==1){if(Col==0)return TEXT("Bedroom");if(Col==1)return TEXT("Bathroom");}
 return TEXT("Hallway");
}
bool AHHGameMode::UsePowerUp(const FString& Type,const FString& GuessRoom)
{
 if(RoundState!=EHHRoundState::Seeking||bPowerUsed||PowerInventory.FindRef(Type)<=0)return false;
 AHHSpot* Target=nullptr;
 for(TActorIterator<AHHSpot> It(GetWorld());It;++It)if(It->SpotId==HiddenSpot){Target=*It;break;}
 if(!Target)return false;
 const FString RealRoom=Target->RoomName;
 if(Type==TEXT("eliminate"))
 {
  TArray<FString> Options={TEXT("Living Room"),TEXT("Kitchen"),TEXT("Garage"),TEXT("Bedroom"),TEXT("Bathroom")};Options.Remove(RealRoom);
  for(const FString& Room:EliminatedRooms)Options.Remove(Room);
  if(!Options.Num())return false;
  const FString Clear=Options[FMath::RandRange(0,Options.Num()-1)];EliminatedRooms.Add(Clear);Feedback=TEXT("Eliminated: ")+Clear;
 }
 else if(Type==TEXT("hotcold")){HotColdRemaining=10.f;Feedback=TEXT("Hot/Cold active for 10 seconds");}
 else if(Type==TEXT("fifty")){if(GuessRoom.IsEmpty())return false;const bool bCorrect=GuessRoom.Equals(RealRoom,ESearchCase::IgnoreCase);Finish(bCorrect);Feedback=bCorrect?TEXT("Correct room: you win!"):TEXT("Wrong room: you lose!");}
 else return false;
 PowerInventory[Type]=PowerInventory.FindRef(Type)-1;bPowerUsed=true;return true;
}
