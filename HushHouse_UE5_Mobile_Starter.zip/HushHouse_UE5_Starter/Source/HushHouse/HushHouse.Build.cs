using UnrealBuildTool;
public class HushHouse : ModuleRules { public HushHouse(ReadOnlyTargetRules Target):base(Target) { PCHUsage=PCHUsageMode.UseExplicitOrSharedPCHs; PublicDependencyModuleNames.AddRange(new string[]{"Core","CoreUObject","Engine","InputCore","EnhancedInput","UMG","Json","JsonUtilities"}); } }
