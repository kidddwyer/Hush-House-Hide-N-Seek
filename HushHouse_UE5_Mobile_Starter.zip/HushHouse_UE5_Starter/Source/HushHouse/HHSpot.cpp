#include "HHSpot.h"
#include "Components/SphereComponent.h"
AHHSpot::AHHSpot()
{
 PrimaryActorTick.bCanEverTick=false;
 Area=CreateDefaultSubobject<USphereComponent>(TEXT("SpotArea")); SetRootComponent(Area);
 Area->InitSphereRadius(140.f);Area->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}
