using UnrealBuildTool;
public class HushHouseTarget : TargetRules { public HushHouseTarget(TargetInfo Target) : base(Target) { Type = TargetType.Game; DefaultBuildSettings = BuildSettingsVersion.V5; ExtraModuleNames.Add("HushHouse"); } }
