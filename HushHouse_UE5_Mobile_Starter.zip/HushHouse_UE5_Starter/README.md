# Hush House — Unreal Engine 5 Mobile Starter Project

This is **a source Unreal Engine project scaffold**, NOT a cooked iOS/Android app. Built from the prior browser prototype data, with 46 spot definitions and the first three textured GLB furniture assets.

## What you can open / run
1. Install Unreal Engine 5.5 or a compatible UE5 release, Visual Studio C++ toolchain on Windows (or Xcode on macOS), and iOS/Android toolchain for device packaging.
2. Unzip, right-click `HushHouse.uproject` to generate IDE project files, and open it in Unreal Editor; compile C++.
3. Enable Editor Scripting Utilities/Python if needed. Open Tools > Execute Python Script and run `Editor/setup_level.py` (or run its contents from Python console). This creates `/Game/Maps/StarterHouse` with an `AHHHouse` generator.
4. Project Settings > Maps & Modes: set Game Default Map to `/Game/Maps/StarterHouse`; save.
5. Press Play. The starter house builds at runtime as a **gray/placeholder mesh blockout** until material assets are assigned. Walking: WASD; look: mouse; hide/search: E (after starting practice, via Blueprint call to `BeginPractice`).
6. Run `Editor/import_glb.py` to import the sectional, bed and island models. The importer opens UI in some UE versions, so verify mesh axes, scale, materials and slot names.

## Current gameplay implementation
- `AHHCharacter`: first-person camera, capsule collision, keyboard/mobile joystick input bindings, proximity-based spot selection, interaction and power-up calls.
- `AHHSpot`: location/name/room metadata.
- `AHHGameMode`: simulated hide/seek practice timers (90/180 sec), proximity searching, one seeker power-up per round, 50/50 win/loss, room elimination, Hot/Cold for 10 seconds. Practice does not reward stars.
- `AHHHouse`: runtime builder for **five rooms**, floors/walls with real doorway gaps, furniture blockouts and **46 searchable spots** from JSON.
- `ImportAssets/`: actual `.glb` meshes and material images from the browser build.
- `LegacyBackend/`: original Node server for future HTTP API integration.

## Known limitations and next steps
- An Unreal Editor-built `.umap`, cooked `.uasset`s, packaged mobile apps, compiled native binaries, complete mobile HUD, multiplayer API bridge, shopping UI, and high-quality final materials are **not included**. They require Unreal Editor compilation/integration and on-device testing.
- The `GameMode` requires an explicit `BeginPractice` call from a menu Blueprint or Level Blueprint. There is currently no user-facing practice menu.
- On-device iOS C++ shipping will need a Mac, Xcode and signing. Android needs Android SDK/NDK configuration. See Epic Mobile Project Setup.
- Wall collision/visual scale and room materials should be checked in-editor. The C++ blockout intentionally uses basic meshes and placeholder engine material; theme colors are recorded for the authoring pass but not bound to dynamic materials yet.

See `Docs/MOBILE_UI_AND_BACKEND.md` and `Docs/ASSET_MAPPING.md`.
