"""Run from UE Python console: exec(open(r'<PROJECT>/Editor/setup_level.py').read()).
Creates a real Entry map containing the runtime starter house generator.
"""
import unreal
world=unreal.EditorLevelLibrary.new_level('/Game/Maps/StarterHouse')
actor_cls=unreal.load_class(None,'/Script/HushHouse.HHHouse')
assert actor_cls, 'Compile C++ module before running this script'
unreal.EditorLevelLibrary.spawn_actor_from_class(actor_cls,unreal.Vector(0,0,0))
player=unreal.EditorLevelLibrary.spawn_actor_from_class(unreal.PlayerStart,unreal.Vector(600,420,100))
unreal.EditorLevelLibrary.save_current_level()
print('StarterHouse.umap saved. Set Game Default Map to /Game/Maps/StarterHouse in Project Settings > Maps & Modes.')
