"""Run inside Unreal Editor after Python plugin enabled. Reimports textures and static meshes."""
import unreal, os
root=os.path.abspath(os.path.join(unreal.Paths.project_dir(),'ImportAssets'))
assets=['sectional.glb','bed.glb','island.glb']
asset_tools=unreal.AssetToolsHelpers.get_asset_tools()
for f in assets:
 path=os.path.join(root,f)
 task=unreal.AssetImportTask()
 task.set_editor_property('filename',path)
 task.set_editor_property('destination_path','/Game/Furniture/Imported')
 task.set_editor_property('automated',False)
 task.set_editor_property('replace_existing',True)
 task.set_editor_property('save',True)
 asset_tools.import_asset_tasks([task])
 print('Imported',f,task.get_editor_property('imported_object_paths'))
print('Review mesh scale, texture slots, tangent basis, and collider setup in editor before replacing blockouts.')
